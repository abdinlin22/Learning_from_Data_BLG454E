import numpy as np
# Do not import any other libraries.


class KMeans:

    def __init__(self, X, n_clusters):
        self.X = X
        self.n_clusters = n_clusters
        self.centroids = X[np.random.choice(X.shape[0], n_clusters, replace=False)]

    def mean(self, value):
        """
        Calculate mean of the dataset column-wise.
        Do not use built-in functions

        :param value: data
        :return the mean value
        """
        sum_values = [0] * value.shape[1]               # Initializing sum for each column
        for row in value:
            for i in range(len(row)):
                sum_values[i] += row[i]                 # Summing up each column
        return [sum_val / value.shape[0] for sum_val in sum_values]     # Calculating mean for each column
        raise NotImplementedError


    def std(self):
        """
        Calculate standard deviation of the dataset.
        Use the mean function you wrote. Do not use built-in functions

        :param X: dataset
        :return the standard deviation value
        """
        mean_self = self.mean(self.X)           # Calculating the mean using the mean function
        variance = [0] * self.X.shape[1]        # Initializing variance for each column
        for row in self.X:
            for i in range(len(row)):
                variance[i] += (row[i] - mean_self[i]) ** 2             # Summing up squared differences

        # Calculating variance and standard deviation for each column
        variance = [var / (self.X.shape[0] - 1) for var in variance]
        std_value = [var ** 0.5 for var in variance]
        return std_value
        raise NotImplementedError

    def standard_scaler(self):
        """
        Implement Standard Scaler to X.
        Use the mean and std functions you wrote. Do not use built-in functions

        :param X: dataset
        :return X_scaled: standard scaled X
        """
        mean_scaler = self.mean(self.X)         # Calculating the mean
        std_value = self.std()                  # Calculating the standard deviation
        X_scaled = []
        for row in self.X:
            # Scaling each row using the mean and standard deviation
            scaled_row = [(row[i] - mean_scaler[i]) / std_value[i] for i in range(len(row))]
            X_scaled.append(scaled_row)
        return np.array(X_scaled)
        raise NotImplementedError

    def euclidean_distance(self, point1, point2):
        """
        Calculate the Euclidean distance between two data points.
        Do not use any external libraries

        :param point1: data point 1, list of floats
        :param point2: data point 2, list of floats

        :return the Euclidean distance between two data points
        """

        # Calculating the Euclidean distance using the formula
        euclidean_distance = sum((point1[i] - point2[i]) ** 2 for i in range(len(point1))) ** 0.5
        return euclidean_distance
        raise NotImplementedError

    def get_closest_centroid(self, point):
        """
        Find the closest centroid given a data point.

        :param point: list of floats
        :param centroids: a list of list where each row represents the point of each centroid
        :return: the number(index) of the closest centroid
        """

        # Calculating the distance from the point to each centroid
        distances = [self.euclidean_distance(point, centroid) for centroid in self.centroids]
        return np.argmin(distances)
        raise NotImplementedError

    def update_clusters(self):
        """
        Assign all data points to the closest centroids.
        Use "get_closest_centroid" function

        :return: cluster_dict: a  dictionary  whose keys are the centroids' key names and values are lists of points that belong to the centroid
        Example:
        list_of_points = [[1.1, 1], [4, 2], [0, 0]]
        centroids = [[1, 1],
                    [2, 2]]

            print(update_clusters())
        Output:
            {'0': [[1.1, 1], [0, 0]],
             '1': [[4, 2]]}
        """

        # Initializing a dictionary to hold clusters
        cluster_dict = {str(i): [] for i in range(len(self.centroids))}
        for point in self.X:
            # Finding the closest centroid for each point and add the point to the corresponding cluster
            closest_centroid = self.get_closest_centroid(point)
            cluster_dict[str(closest_centroid)].append(point)
        return cluster_dict
        raise NotImplementedError

    def update_centroids(self, cluster_dict):
        """
        Update centroids using the mean of the given points in the cluster.
        Doesn't return anything, only change self.centroids
        Use your mean function.
        Consider the case when one cluster doesn't have any point in it !

        :param cluster_dict: a  dictionary  whose keys are the centroids' key names and values are lists of points that belong to the centroid

        """
        new_centroids = []
        for key in cluster_dict:
            if len(cluster_dict[key]) == 0:
                new_centroids.append(self.centroids[int(key)])      # If a cluster has no points, retain the old centroid
            else:
                # Calculating the new centroid as the mean of the cluster points
                new_centroids.append(self.mean(np.array(cluster_dict[key])))
        self.centroids = np.array(new_centroids)
       

    def converged(self, clusters, old_clusters, tolerance=1e-6):
        """
        Check the clusters converged or not

        :param clusters: new clusters, dictionary where keys are cluster labels and values are the points(list of list)
        :param old_clusters: old clusters, dictionary where keys are cluster labels and values are the points(list of list)
        :return: boolean value: True if clusters don't change
        Example:
        clusters = {'0': [[1.1, 1], [0, 0]],
                    '1': [[4, 2]]}
        old_clusters = {'0': [[1.1, 1], [0, 0]],
                        '1': [[4, 2]]}
            print(update_assignment(clusters, old_clusters))
        Output:
            True
        """
        if old_clusters is None:
            return False            # If old clusters are None, they haven't converged
        for key in clusters:
            # Checking if any cluster has changed
            if not np.array_equal(np.array(clusters[key]), np.array(old_clusters[key])):
                return False
        return True
        raise NotImplementedError
        

    def calculate_wcss(self, clusters):
        """

        :param clusters: dictionary where keys are clusters labels and values the data points belong to that cluster
        :return:
        """
        wcss = 0
        for key in clusters:
            centroid = self.centroids[int(key)]
            # Summing the squared distances from each point to the centroid
            for point in clusters[key]:
                wcss += self.euclidean_distance(point, centroid) ** 2
        return wcss

    def fit(self):
        """
        Implement K-Means clustering until the clusters don't change.
        Use the functions you have already implemented.
        Print how many steps does it take to converge.
        :return: final_clusters: a  dictionary  whose keys are the centroids' key names and values are lists of points that belong to the centroid
                 final_centroids: list of list with shape (n_cluster, X.shape[1])
                 wcss: within-cluster sum of squares
        """
        steps = 0
        old_clusters = None
        clusters = self.update_clusters()       # Initial clustering

        while not self.converged(clusters, old_clusters):
            old_clusters = clusters
            self.update_centroids(clusters)         # Updating centroids
            clusters = self.update_clusters()       # Reassigning points to clusters
            steps += 1

        print(f'Converged in {steps} steps.')

        # Calculating WCSS
        wcss = self.calculate_wcss(clusters)
        return clusters, self.centroids, wcss
        raise NotImplementedError
